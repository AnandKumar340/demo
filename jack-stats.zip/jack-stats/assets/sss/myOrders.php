<!DOCTYPE html>
<html lang="en">
<?php include 'include/head.php'; ?>

     <link rel="stylesheet" type="text/css" href="assets/vendors/css/tables/datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="assets/vendors/css/ui/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="assets/vendors/css/forms/selects/select2.min.css">
    <!-- END: Vendor CSS-->
		<?php include 'include/top-bar.php'; ?>
        <?php include 'include/left_sidebar.php'; ?>
         
	<div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Seller Account</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Home</a>
                  </li>
                  <li class="breadcrumb-item active"> Sales
                  </li>
                </ol>
              </div>
            </div>
          </div>
         <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
              <a href="#" class="ad_pro_btn">Add Product</a><button class="btn bg-danger white mb-1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-angle-down"></i></button>
              <div class="dropdown-menu arrow">
              <a class="dropdown-item" href="#">Simple Product</a>
              <a class="dropdown-item" href="#">Downloadable Product</a>
              <a class="dropdown-item" href="#">Virtual Product</a>
              
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><section class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-header">
				<div class="heading-elements"> 
					<span class="dropdown">
						<button id="btnSearchDrop1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-warning btn-sm  dropdown-menu-right"><i
							 class="ft-filter white"></i> Filters</button>
						<span aria-labelledby="btnSearchDrop1" class="dropdown-menu mt-1 dropdown-menu-right">
							<a href="#" class="dropdown-item"><i class="la la-calendar"></i> Due Date</a>
							<a href="#" class="dropdown-item"><i class="la la-random"></i> Priority </a>
							<a href="#" class="dropdown-item"><i class="la la-bar-chart"></i> Progress</a>
							<a href="#" class="dropdown-item"><i class="la la-user"></i> Assign to</a>
						</span>
					</span>
					<button class="btn btn-success btn-sm"><i class="ft-settings white"></i> Columns</button>
                    <div class="form-group mt-1"> 
											<select id="projectinput5" name="interested" class="form-control"> 
												<option value="Actions">Actions</option>
												<option value="Delete">Delete</option>
												<option value="Change status">Change status</option>  
											</select>
										</div>
				</div>
			</div>
			<div class="card-content">
				<div class="card-body">
					<!-- Task List table -->
					<div class="table-responsive">
						<table id="project-task-list" class="table ordr_my_tbl table-white-space table-bordered row-grouping display no-wrap icheck table-middle mt-1">
							<thead>
								<tr class="bg-danger white">
									<th class="linheigt"><div class="custom-control custom-checkbox hd_topchk">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall">
                      <label class="custom-control-label" for="checkboxsmallall"></label>
                    </div></th>
									<th class="linheigt">ID	</th>
									<th class="linheigt">Purchase Point</th>
									<th class="linheigt">Purchase Date</th>
									<th class="linheigt">Bill-to Name</th>
									<th class="linheigt">Ship-to Name</th>
                                    <th>Grand Total<br> (Purchased)		</th>
									<th class="linheigt">Status	</th>
									<th class="linheigt">Action</th> 
								</tr>
							</thead>
							<tbody>
								<!-- ABC Project -->
								<tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-danger round">Canceled	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
								   
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge ">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-warning round">Processing</button>	
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-danger round">Canceled	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
								   
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge ">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-warning round">Processing</button>	
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-danger round">Canceled	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
								   
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge ">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-warning round">Processing</button>	
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-danger round">Canceled	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
                                
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-success round">Complete	</button>		
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
								   
                                <tr>
									<td><div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="checkboxsmallall11">
                      <label class="custom-control-label" for="checkboxsmallall11"></label>
                    </div></th></td>
									<td>
										000000058
									</td>
									<td>
										<div class="data-grid-cell-content">Main Website<br>
                                           Main Website Store<br>
                                              Default Store View</div>
									</td>
									<td><span class="badge ">Nov 06, 2020, 2:11:00 AM</span></td>
									<td>
										Demo Store
									</td>

									<td class="text-center">
										Demo Store	
									</td>
									 
                                    <td class="bld_tex">
										$767.00
									</td>
                                    <td>
									<button type="button" class="btn btn-sm btn-warning round">Processing</button>	
									</td>
                                     
                                    <td>
										<a href="#">View</a>
									</td>
								</tr>
							</tbody> 
						</table>
					</div>
					<!--/ Task List table -->
				</div>
			</div>
		</div>
	</div>
</section>
        </div>
        
        
        
      </div>
    </div> 
		




<?php include 'include/footer.php'; ?>
<?php include 'include/foot.php'; ?>
 
  
  <!-- BEGIN: Page Vendor JS-->
    <script src="assets/vendors/js/tables/jquery.dataTables.min.js"></script>
    <script src="assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="assets/js/core/libraries/jquery_ui/jquery-ui.min.js"></script>
    <script src="assets/js/scripts/ui/jquery-ui/date-pickers.min.js"></script>
    <script src="assets/vendors/js/forms/select/select2.min.js"></script>
    <!-- END: Page Vendor JS-->
 

    <!-- BEGIN: Page JS-->
    <script src="assets/js/scripts/pages/project-task-list.min.js"></script>